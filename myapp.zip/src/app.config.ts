export default {
  pages: [
    'pages/index/index'
  ],
  window: {
    backgroundTextStyle: 'dark',
    navigationBarBackgroundColor: '#FFFAFA',
    navigationBarTitleText: 'WeChat',
    navigationBarTextStyle: 'black'
  }
}
